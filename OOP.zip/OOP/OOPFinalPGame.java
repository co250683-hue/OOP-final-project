import javax.swing.*;
import java.awt.*;

//Custom Exception (EXCEPTION HANDLING: our own exception type)
class InvalidChoiceException extends Exception {
    public InvalidChoiceException(char choice) {
        super("Invalid choice: " + choice);
    }
}

//Abstract Class (ABSTRACTION)

abstract class rTemplate    {

    //ENCAPSULATION: fields are private, only reachable through getters/setters
    private String head, hint, optL, optR, dthMsg;

    public String getHead()   {
        return head;
    }

    public String getHint() {
        return hint;
    }

    public String getOptL() {
        return optL;
    }

    public String getOptR() {
        return optR;
    }

    public String getDthMsg() {
        return dthMsg;
    }

    //Protected setters: only subclasses (the rooms) can change the data
    protected void setHead(String head) {
        this.head = head;
    }

    protected void setHint(String hint) {
        this.hint = hint;
    }

    protected void setOptL(String optL) {
        this.optL = optL;
    }

    protected void setOptR(String optR) {
        this.optR = optR;
    }

    protected void setDthMsg(String dthMsg) {
        this.dthMsg = dthMsg;
    }

    //Abstraction Method for Polymorphism (Different Room Different Response)
    public abstract boolean choiceIdentify(char choice);
}

//Normal Room (INHERITANCE from our Room Template/rTemplate)

class Rooms extends rTemplate {
    private char correct;

    public Rooms(int rNum, String headText, String optLText, String optRText, char correctChar, String dthMsg) {
        setHead("Room No. " +  rNum);
        setHint(headText);
        setOptL(optLText);
        setOptR(optRText);
        this.correct = Character.toUpperCase(correctChar); //User gives lower case Response (Automatically changes it into Upper Case)
        setDthMsg(dthMsg);
    }

    //POLYMORPHISM: overrides the abstract method
    @Override
    public boolean choiceIdentify(char choice) {
        return Character.toUpperCase(choice) == this.correct;
    }
}

//Final Room with the Finale Twist (INHERITANCE + POLYMORPHISM: same method, different behavior)

class FinaleRoom extends rTemplate {
    private int steps = 1;

    public FinaleRoom() {
        setHead("LAST EXIT");
        setHint("Pixie: I'm sorry but only 1 Person can leave! \n Whose it going to be?");
        setOptL("Pixie Escapes");
        setOptR("Save Yourself");
        setDthMsg("You have now become the Pixie!");
    }

    @Override
    public boolean choiceIdentify(char choice) {
        char up =  Character.toUpperCase(choice);
        if (steps == 1) {
            if (up == 'L')    {
                return false; //User picked the Wrong choice, program triggers Game Over
            }   else {
                steps = 2; //Moving into the Second Stage of the Finale Room
                setHint("Pixie: You are going to leave me behind? \n Are you sure?");
                setOptL("Yes, leave her Alone");
                setOptR("No, let her Escape");
                return false;
            }
        } else {
            return up == 'L';
        }
    }
}

//Shared colors, fonts and button styling
class Theme {
    static final Color BG = new Color(22,22,22);
    static final Color PANEL = new Color(92, 61, 41);
    static final Color RED = new Color(196, 0, 0);
    static final Color RED_HOVER = new Color(255, 0, 0);
    static final Color BLUE = new Color(0, 0, 125);
    static final Color BLUE_HOVER = new Color(0, 0, 190);
    static final Color DARKRED = new Color(220, 60, 70);
    static final Color DARKRED_HOVER = new Color(255, 100, 110);
    static final Color GREEN = new Color(67, 200, 120);
    static final Color TEXT = new Color(235, 235, 245);
    static final Color PIXIE = new Color(255, 241, 0);
    static final Color NARRATOR = new Color(44, 44, 44);

    static final Font TITLE = new Font("Georgia", Font.BOLD, 28);
    static final Font BODY = new Font("Georgia", Font.PLAIN, 17);
    static final Font BTN = new Font("Arial", Font.BOLD, 15);

    static void styleButton(JButton b, Color base, Color hover) {
        b.setFont(BTN);
        b.setForeground(Color.WHITE);
        b.setBackground(base);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(base); }
        });
    }

    //Shows an error popup (used by the catch blocks)
    static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    //Loads a picture from the "images" folder and resizes it (returns null if the file is missing, so the game still runs)
    static java.io.File imagesDir = null; //remembers where the images folder was found

    static ImageIcon loadImage(String path, int w, int h) {
        Image raw = null;
        String rel = path.startsWith("/") ? path.substring(1) : path;
        String name = rel.substring(rel.lastIndexOf('/') + 1);

        //1) Try the classpath first (works in NetBeans, IntelliJ, Maven)
        java.net.URL url = Theme.class.getResource(path);
        if (url != null) {
            raw = new ImageIcon(url).getImage();
        }

        //2) Fallback for VS Code: look in the folder the game was started from, then src, then bin
        if (raw == null) {
            String[] bases = {"", "src/", "bin/"};
            for (String b : bases) {
                java.io.File f = new java.io.File(b + rel);
                if (f.exists()) {
                    raw = new ImageIcon(f.getPath()).getImage();
                    break;
                }
            }
        }

        //3) Last resort: remember/search the folders below where the game was started for an "images" folder
        if (raw == null && imagesDir != null) {
            java.io.File f = new java.io.File(imagesDir, name);
            if (f.exists()) raw = new ImageIcon(f.getPath()).getImage();
        }
        if (raw == null) {
            try (java.util.stream.Stream<java.nio.file.Path> s = java.nio.file.Files.walk(java.nio.file.Paths.get("."), 4)) {
                java.util.Optional<java.nio.file.Path> hit = s.filter(p -> p.getFileName() != null
                        && p.getFileName().toString().equals(name)
                        && p.getParent() != null && p.getParent().getFileName() != null
                        && p.getParent().getFileName().toString().equals("images")).findFirst();
                if (hit.isPresent()) {
                    imagesDir = hit.get().getParent().toFile();
                    System.out.println("Found images folder at: " + imagesDir.getAbsolutePath());
                    raw = new ImageIcon(hit.get().toString()).getImage();
                }
            } catch (Exception ex) {
                //search failed, picture will simply be skipped
            }
        }

        if (raw == null) {
            System.out.println("Image not found: " + path + " (running from: " + new java.io.File(".").getAbsolutePath() + ")");
            return null; //game still runs, just without the picture
        }
        return new ImageIcon(raw.getScaledInstance(w, h, Image.SCALE_SMOOTH));
    }
}

//Start Screen Window (separate JFrame)
class StartFrame extends JFrame {
    public StartFrame() {
        setTitle("Doors Escape Game");
        setSize(500, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BG);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("DOORS ESCAPE", SwingConstants.CENTER);
        title.setFont(new Font("Georgia", Font.BOLD, 34));
        title.setForeground(Theme.RED_HOVER);
        title.setOpaque(true);
        title.setBackground(Theme.PANEL);
        title.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
        add(title, BorderLayout.NORTH);

        JTextArea rules = new JTextArea(
                "RULES\n\n" +
                        "• Read each riddle carefully\n" +
                        "• Choose Left or Right to make your decision\n" +
                        "• Survive all rooms to earn your victory");
        rules.setEditable(false);
        rules.setLineWrap(true);
        rules.setWrapStyleWord(true);
        rules.setFont(Theme.BODY);
        rules.setForeground(Theme.TEXT);
        rules.setBackground(Theme.BG);
        rules.setMargin(new Insets(25, 40, 25, 40));
        add(rules, BorderLayout.CENTER);

        JButton startButton = new JButton("START GAME");
        Theme.styleButton(startButton, Theme.DARKRED, Theme.DARKRED_HOVER);
        startButton.setPreferredSize(new Dimension(0, 60));
        startButton.addActionListener(e -> {
            try {
                IntroFrame intro = new IntroFrame(); //opens the opening dialogue first
                intro.setVisible(true);
                dispose();                           //only close this window if it worked
            } catch (Exception ex) {
                Theme.showError(this, "The intro could not start:\n" + ex.getMessage());
            }
        });
        add(startButton, BorderLayout.SOUTH);
    }
}

//Opening Dialogue Window (separate window, plays before the game)
class IntroFrame extends JFrame {
    //Each line is {speaker, text}
    private final String[][] script = {
            {"NARRATOR", "You awaken on a cold stone floor. Your head is pounding, and you have no memory of how you got here."},
            {"NARRATOR", "The room is silent. Ahead of you stand two heavy doors, each with a single word carved into its surface."},
            {"NARRATOR", "A small light flickers in the air and drifts toward you. It slowly takes the shape of a tiny winged girl, a pixie!"},
            {"PIXIE", "You're awake! Thank goodness... Please don't be scared, I'm here to help you!"},
            {"PIXIE", "I was given a task.. to give you clues that lead to the correct door, so that both of us can escape this place!"},
            {"PIXIE", "Pass every door and you will leave with your life. But choose wrong..."},
            {"PIXIE", "...and you will die by the very door you chose."},
            {"PIXIE", "Listen to my clues carefully. Our lives depend on it. Are you ready? Then let's begin!"}
    };

    private int line = 0;     //which line of the script we are on
    private int charPos = 0;  //how many letters are currently shown

    private JLabel speakerLabel = new JLabel("", SwingConstants.CENTER);
    private JTextArea dialogueArea = new JTextArea();
    private JButton nextButton = new JButton("SKIP");
    private javax.swing.Timer typer;
    private JLabel pixiePic = new JLabel(Theme.loadImage("/images/pixie.png", 120, 120)); //picture of the Pixie

    public IntroFrame() {
        setTitle("Doors Escape Game");
        setSize(580, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BG);
        setLayout(new BorderLayout());

        //Speaker name bar
        speakerLabel.setFont(Theme.TITLE);
        speakerLabel.setOpaque(true);
        speakerLabel.setBackground(Theme.PANEL);
        speakerLabel.setBorder(BorderFactory.createEmptyBorder(18, 10, 18, 10));
        add(speakerLabel, BorderLayout.NORTH);

        // Dialogue text
        dialogueArea.setEditable(false);
        dialogueArea.setLineWrap(true);
        dialogueArea.setWrapStyleWord(true);
        dialogueArea.setFont(Theme.BODY);
        dialogueArea.setForeground(Theme.TEXT);
        dialogueArea.setBackground(Theme.BG);
        dialogueArea.setMargin(new Insets(30, 40, 30, 40));
        add(dialogueArea, BorderLayout.CENTER);

        //Pixie picture on the left side
        pixiePic.setOpaque(true);
        pixiePic.setBackground(Theme.BG);
        pixiePic.setBorder(BorderFactory.createEmptyBorder(0, 25, 0, 0));
        add(pixiePic, BorderLayout.WEST);

        // Skip button
        Theme.styleButton(nextButton, Theme.DARKRED, Theme.DARKRED_HOVER);
        nextButton.setPreferredSize(new Dimension(0, 60));
        nextButton.addActionListener(e -> onButton());
        add(nextButton, BorderLayout.SOUTH);

        //Typewriter effect, adds one letter every 30 milliseconds
        typer = new javax.swing.Timer(30, e -> typeNextLetter());

        showLine();
    }

    //Starts typing the current line
    void showLine() {
        try {
            String speaker = script[line][0];
            speakerLabel.setText(speaker);
            speakerLabel.setForeground(speaker.equals("PIXIE") ? Theme.PIXIE : Theme.NARRATOR);
            pixiePic.setVisible(speaker.equals("PIXIE")); //only show the Pixie while she is talking

            charPos = 0;
            dialogueArea.setText("");
            nextButton.setText("SKIP");
            typer.restart();
        } catch (ArrayIndexOutOfBoundsException ex) {
            Theme.showError(this, "The dialogue could not be loaded.");
            System.exit(1);
        }
    }

    //Called by the timer to reveal the next letter
    void typeNextLetter() {
        String text = script[line][1];
        if (charPos < text.length()) {
            charPos++;
            dialogueArea.setText(text.substring(0, charPos));
        } else {
            finishLine();
        }
    }

    //Stops the typing and shows the whole line
    void finishLine() {
        typer.stop();
        dialogueArea.setText(script[line][1]);
        nextButton.setText(line == script.length - 1 ? "ENTER THE DOORS" : "NEXT");
    }

    //What the button does depends on the state of the dialogue
    void onButton() {
        if (typer.isRunning()) {
            finishLine();               //still typing, so show the full line
        } else if (line < script.length - 1) {
            line++;                     //go to the next line
            showLine();
        } else {
            startGame();                //dialogue is over
        }
    }

    //Opens the actual game
    void startGame() {
        try {
            OOPFinalPGame game = new OOPFinalPGame(); //build the game first
            game.setVisible(true);
            dispose();                                //only close the intro if the game opened
        } catch (Exception ex) {
            Theme.showError(this, "The game could not start:\n" + ex.getMessage());
        }
    }
}

//Game Over / Victory Window (separate JFrame)
class EndFrame extends JFrame {
    public EndFrame(String title, String message, Color accent, String imagePath) {
        setTitle(title);
        setSize(640, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Theme.BG);
        setLayout(new BorderLayout());

        JLabel ttl = new JLabel(title, SwingConstants.CENTER);
        ttl.setFont(new Font("Georgia", Font.BOLD, 36));
        ttl.setForeground(accent);
        ttl.setOpaque(true);
        ttl.setBackground(Theme.PANEL);
        ttl.setBorder(BorderFactory.createEmptyBorder(25, 10, 25, 10));
        add(ttl, BorderLayout.NORTH);

        //Picture for this screen
        JLabel pic = new JLabel(Theme.loadImage(imagePath, 600, 337), SwingConstants.CENTER);

        JLabel msg = new JLabel(
                "<html><div style='text-align:center; width:320px;'>"
                        + message.replace("\n", "<br>") + "</div></html>",
                SwingConstants.CENTER);
        msg.setFont(Theme.BODY);
        msg.setForeground(Theme.TEXT);

        //Picture on top, message under it
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Theme.BG);
        center.add(pic, BorderLayout.NORTH);
        center.add(msg, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JButton exitButton = new JButton("EXIT");
        Theme.styleButton(exitButton, accent.darker(), accent);
        exitButton.setPreferredSize(new Dimension(0, 55));
        exitButton.addActionListener(e -> System.exit(0));
        add(exitButton, BorderLayout.SOUTH);
    }
}

//MAIN PART WITH JFRAME
public class OOPFinalPGame extends JFrame {
    //COMPOSITION: The Window/Game has an Array of Rooms/Stages (and owns its GUI components)
    private rTemplate[] space = new rTemplate[6];
    private int index = 0;

    //GUI Components needed
    private JLabel ttlLabel = new JLabel("Title", SwingConstants.CENTER);
    private JLabel roomPic = new JLabel("", SwingConstants.CENTER); //picture of the current door/room
    private JTextArea textArea = new JTextArea(10, 25);
    private JButton leftButton = new JButton("LEFT");
    private JButton rightButton = new JButton("RIGHT");

    public OOPFinalPGame() {
        setTitle("Escape Game");
        setSize(1280, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        //Components for the Window
        add(ttlLabel, BorderLayout.NORTH);

        //Picture on top, riddle text under it
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Theme.BG);
        center.add(roomPic, BorderLayout.NORTH);
        center.add(new JScrollPane(textArea), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(1,2));
        buttonPanel.add(leftButton);
        buttonPanel.add(rightButton);
        add(buttonPanel, BorderLayout.SOUTH);

        textArea.setEditable(false);
        textArea.setLineWrap(true);

        //Buttons to be Clicked
        leftButton.addActionListener(e -> play('L'));
        rightButton.addActionListener(e -> play('R'));

        //Styling the Window
        applyTheme();

        //Initializing the Game
        gameInitialize();

    }

    private void gameInitialize() {
        try {
            space[0] = new Rooms(1, "Has the Strength to pull a Plow, yet gets Aggravated to a Red Cape.", "Bull", "Stallion", 'L', "Trampled by the Hooves of the Stallion!");
            space[1] = new Rooms(2, "Sent down by Space conquering Earth, Cheap by Price, however Valuable for War", "Gold", "Iron", 'R', "Executed by the Ruthless Blood Knight!");
            space[2] = new Rooms(3, "If it weren't for requirements, I'd be the Largest.", "Sahara Desert", "Antarctica", 'R', "Poisoned by Sulphuric Acid!");
            space[3] = new Rooms(4, "I get Damper whenever something needs to be dry.", "Towel", "Sponge", 'L', "Burned into Ashes!");
            space[4] = new Rooms(5, "I do not ask questions, yet somehow I am always answered.", "Puppet", "Doorbell", 'R', "Haunted by the Puppet Master!");
            space[5] = new FinaleRoom();

            index = 0;
            uiChanges();
        } catch (ArrayIndexOutOfBoundsException ex) {
            //Happens if more rooms are added than the array can hold
            Theme.showError(this, "There are more rooms than the game can hold.\nIncrease the size of the 'space' array.");
            System.exit(1);
        } catch (Exception ex) {
            Theme.showError(this, "Failed to set up the rooms:\n" + ex.getMessage());
            System.exit(1);
        }
    }

    private void applyTheme() {
        setSize(640, 720); //bigger so the 600x337 room picture fits
        getContentPane().setBackground(Theme.BG);

        ttlLabel.setFont(Theme.TITLE);
        ttlLabel.setForeground(Theme.DARKRED_HOVER);
        ttlLabel.setOpaque(true);
        ttlLabel.setBackground(Theme.PANEL);
        ttlLabel.setBorder(BorderFactory.createEmptyBorder(18, 10, 18, 10));

        textArea.setFont(Theme.BODY);
        textArea.setForeground(Theme.TEXT);
        textArea.setBackground(Theme.BG);
        textArea.setWrapStyleWord(true);
        textArea.setMargin(new Insets(25, 30, 25, 30));

        Theme.styleButton(leftButton, Theme.RED, Theme.RED_HOVER);
        Theme.styleButton(rightButton, Theme.BLUE, Theme.BLUE_HOVER);
        leftButton.setPreferredSize(new Dimension(0, 60));


        try {
            ((JScrollPane) textArea.getParent().getParent()).setBorder(null);

            JPanel bp = (JPanel) leftButton.getParent();
            bp.setBackground(Theme.BG);
            bp.setBorder(BorderFactory.createEmptyBorder(10, 15, 15, 15));
            ((GridLayout) bp.getLayout()).setHgap(15);
        } catch (ClassCastException | NullPointerException ex) {
            //Styling is only cosmetic, so the game can keep running without it
            System.out.println("Some styling could not be applied: " + ex);
        }
    }

    //Refreshes Window based on the current Room the User is in
    void uiChanges() {
        try {
            rTemplate r = space[index];
            ttlLabel.setText(r.getHead());
            textArea.setText(r.getHint());
            leftButton.setText(r.getOptL());
            rightButton.setText(r.getOptR());
            //Loads images/room1.png ... images/room6.png (room6 = the Finale)
            roomPic.setIcon(Theme.loadImage("/images/room" + (index + 1) + ".png", 600, 337));
        } catch (ArrayIndexOutOfBoundsException ex) {
            Theme.showError(this, "That room does not exist.");
            System.exit(1);
        } catch (NullPointerException ex) {
            Theme.showError(this, "A room was not set up correctly.");
            System.exit(1);
        }
    }

    //Handling what happens when the User picks an Answer
    private void play(char choice) {
        try {
            //Only Left or Right are valid (throws our custom exception)
            if (choice != 'L' && choice != 'R') {
                throw new InvalidChoiceException(choice);
            }

            rTemplate r = space[index];
            String hintBefore = r.getHint(); //used to detect the Finale moving to its second stage

            //POLYMORPHISM: same call, each room type decides what "correct" means
            if (r.choiceIdentify(choice)) {
                if (index == space.length - 1) {
                    dispose();
                    new EndFrame("VICTORY", "YOU HAVE ESCAPED!", Theme.GREEN, "/images/victory.png").setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "THAT IS CORRECT!");
                    index++;
                    uiChanges();
                }
            }
            // Final Room twist (the hint changed, so the game moved to the next stage)
            else if (r instanceof FinaleRoom && !r.getHint().equals(hintBefore)) {
                uiChanges();
            }
            // If wrong Answer then Game Over
            else {
                dispose();
                //Loads images/death1.png ... images/death6.png (the picture for the room where the player died)
                new EndFrame("GAME OVER", r.getDthMsg(), Theme.RED, "/images/death" + (index + 1) + ".png").setVisible(true);
            }
        } catch (InvalidChoiceException ex) {
            Theme.showError(this, ex.getMessage());
        } catch (ArrayIndexOutOfBoundsException ex) {
            Theme.showError(this, "The game tried to open a room that does not exist.");
        } catch (Exception ex) {
            Theme.showError(this, "Something went wrong:\n" + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ex) {
            System.out.println("Could not set look and feel, using default.");
        }

        UIManager.put("OptionPane.background", Theme.PANEL);
        UIManager.put("Panel.background", Theme.PANEL);
        UIManager.put("OptionPane.messageForeground", Theme.TEXT);
        UIManager.put("OptionPane.messageFont", Theme.BODY);

        SwingUtilities.invokeLater(() -> {
            try {
                new StartFrame().setVisible(true);
            } catch (Exception ex) {
                System.out.println("Could not open the game: " + ex.getMessage());
            }
        });
    }
}